frameworkShortcodeAtts={
	attributes:[
			{
				label:"Box type",
				id:"type",
				controlType:"select-control", 
				selectValues:['notice','error', 'succesful', 'warning', 'standart'],
				defaultValue: 'notice', 
				defaultText: 'notice',
				help:"Select box type"
			},
			{
				label:"Box text",
				id:"text",
				help:"Enter box text)"
			}
			
	],
	defaultContent:"",
	shortcode:"notice"
};
