frameworkShortcodeAtts={
	attributes:[
			{
				label:"Title",
				id:"title",
				help:"Enter title"
			},
			{
				label:"Description",
				id:"desc",
				help:"Enter description"
			},
			{
				label:"Image",
				id:"image",
				help:"Enter image url."
			}
	],
	defaultContent:"",
	shortcode:"process"
};
