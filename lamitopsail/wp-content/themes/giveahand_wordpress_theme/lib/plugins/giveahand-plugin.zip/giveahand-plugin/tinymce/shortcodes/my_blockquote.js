frameworkShortcodeAtts={
	attributes:[
			{
				label:"Quote",
				id:"quote",
				help:"Enter quote."
			},
			{
				label:"Author",
				id:"author",
				help:"Enter author name"
			}
	],
	defaultContent:"",
	shortcode:"blockquote"
};
