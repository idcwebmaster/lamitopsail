frameworkShortcodeAtts={
	attributes:[
			{
				label:"Facebook",
				id:"facebook",
				help:"Enter Facebook account url."
			},
			{
				label:"Twitter",
				id:"twitter",
				help:"Enter Twitter account url."
			},
			{
				label:"Google+",
				id:"google_plus",
				help:"Enter Google+ account url."
			},
			{
				label:"Skype",
				id:"skype",
				help:"Enter Skype account url."
			},
	],
	defaultContent:"",
	shortcode:"social"
};
