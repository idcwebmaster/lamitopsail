frameworkShortcodeAtts={
	attributes:[
			{
				label:"How many posts to show?",
				id:"num",
				help:"This is how many items will be displayed."
			},
			{
				label:"Which category to pull from? ",
				id:"custom_category",
				help:"Enter the slug of the category you'd like to pull posts from. Leave blank if you'd like to pull from all categories."
			}
	],
	defaultContent:"",
	shortcode:"portfolio_cat",
	shortcodeType: "text-replace"
};